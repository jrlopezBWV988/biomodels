"""Build a lean mmCIF of ma-iegv0 + superposed tRNAs for JSmol display."""
import gemmi, gzip, collections, sys
LIGHT = '--light' in sys.argv   # proteins as backbone only (N, CA, C, O); tRNAs keep all atoms
EXCLUDE = {'tXI'}   # tRNA placed on AIMP1 (not a synthetase): left out of the Atlas files
SRC='/home/user/workspace/ma-iegv0_tRNA_overlay/ma-iegv0_with_tRNAs.cif'
st=gemmi.read_structure(SRC); st.setup_entities()
m=st[0]
names={'A':'MetRS','B':'AIMP3','C':'GluProRS','D':'AIMP2','E':'AspRS','F':'GlnRS','G':'ArgRS',
       'H':'LysRS','I':'AIMP1','J':'IleRS','K':'LeuRS','L':'AspRS','M':'LysRS','N':'GluProRS'}
rows=[]; stats=collections.Counter()
for ch in m:
    if ch.name in EXCLUDE: continue
    for r in ch:
        seen={}
        for a in r:
            if a.element.name=='H': stats['H']+=1; continue
            if LIGHT and not ch.name.startswith('t') and a.name not in ('N','CA','C','O'): continue
            k=a.name
            if k in seen:                      # duplicated partial-occupancy atom: keep higher occupancy
                stats['dup']+=1
                if a.occ>seen[k].occ: seen[k]=a
                continue
            seen[k]=a
        for a in seen.values():
            rows.append((ch.name,r.name,r.seqid.num,r.seqid.icode,a.name,a.element.name,a.pos,r.het_flag))
print('atoms',len(rows),dict(stats))
print('het residues',collections.Counter(r[1] for r in rows if r[7]=='H'))
# secondary structure ranges
ss=collections.defaultdict(list)
for l in open('/tmp/sup/ss.txt'):
    c,n,t,s=l.split(); ss[(c,t,int(s))].append(int(n))
helices=[];sheets=[]
for (c,t,s),v in sorted(ss.items(),key=lambda x:(x[0][0],min(x[1]))):
    v.sort(); start=v[0]; prev=v[0]
    for n in v[1:]+[None]:
        if n is None or n!=prev+1:
            (helices if t=='H' else sheets).append((c,start,prev)); start=n
        if n is not None: prev=n
resname={(c,n):rn for c,rn,n,*_ in rows}
def q(s): return '"'+s+'"' if ("'" in s or ' ' in s) else s
out=[]
w=out.append
w('data_ma-iegv0_tRNA_atlas' + ('_light' if LIGHT else ''))
w('_entry.id ma-iegv0_tRNA_atlas')
w('# ma-iegv0 (ModelArchive, doi:10.5452/ma-iegv0) human multi-tRNA synthetase complex model')
w('# with tRNAs placed by superposition of experimental synthetase-tRNA complexes.')
w('# Teaching file: tRNA positions are approximate (rigid template superposition, no refinement).')
w('# Protein chains: '+', '.join(f'{k} {v}' for k,v in names.items()))
w('# tRNA chains (t + amino acid + host chain): tKH tKM tDE tDL tEC tEN tPC tPN tQF tRG tIJ tLK tMA')
w('# Secondary structure: DSSP computed with Jmol 14.31 on the full-atom model.')
if LIGHT: w('# Light version: protein chains keep backbone atoms only (N, CA, C, O); tRNAs keep all heavy atoms.')
w('#')
w('loop_\n_struct_conf.conf_type_id\n_struct_conf.id\n_struct_conf.beg_auth_asym_id\n_struct_conf.beg_auth_seq_id\n_struct_conf.beg_label_comp_id\n_struct_conf.end_auth_asym_id\n_struct_conf.end_auth_seq_id\n_struct_conf.end_label_comp_id')
for i,(c,a,b) in enumerate(helices,1): w(f'HELX_P H{i} {c} {a} {resname[(c,a)]} {c} {b} {resname[(c,b)]}')
w('#\nloop_\n_struct_sheet_range.sheet_id\n_struct_sheet_range.id\n_struct_sheet_range.beg_auth_asym_id\n_struct_sheet_range.beg_auth_seq_id\n_struct_sheet_range.beg_label_comp_id\n_struct_sheet_range.end_auth_asym_id\n_struct_sheet_range.end_auth_seq_id\n_struct_sheet_range.end_label_comp_id')
for i,(c,a,b) in enumerate(sheets,1): w(f'S{i} 1 {c} {a} {resname[(c,a)]} {c} {b} {resname[(c,b)]}')
w('#\nloop_\n_atom_site.group_PDB\n_atom_site.type_symbol\n_atom_site.auth_atom_id\n_atom_site.auth_comp_id\n_atom_site.auth_asym_id\n_atom_site.auth_seq_id\n_atom_site.pdbx_PDB_ins_code\n_atom_site.Cartn_x\n_atom_site.Cartn_y\n_atom_site.Cartn_z')
for c,rn,n,ic,an,el,p,het in rows:
    w(f"ATOM {el} {q(an)} {rn} {c} {n} {ic.strip() or '?'} {p.x:.2f} {p.y:.2f} {p.z:.2f}")
w('#')
txt='\n'.join(out)+'\n'
OUT='ma-iegv0_tRNA_atlas'+('_light' if LIGHT else '')
open(OUT+'.cif','w').write(txt)
with gzip.open(OUT+'.cif.gz','wb',compresslevel=9) as f: f.write(txt.encode())
print('helices',len(helices),'strands',len(sheets))
