"""Simplified, didactic model of the human pyruvate dehydrogenase complex (PDC).

Experimental coordinates
  6CT0  human E2 catalytic (inner-core) domain; 60-mer from the deposited icosahedral assembly
  1NI4  human E1 (alpha2 beta2) with ThDP
  1ZY8  human E3 dimer bound to the E3-binding domain (E3BD) of human E3BP
  1FYC  human E2 inner lipoyl domain (L2), NMR
  1W85  G. stearothermophilus E1 + PSBD: used only to transfer the PSBD and its position onto human E1
Illustrative (not experimental)
  - symmetric placement of 20 E1 (3-fold axes) and 12 E3 (5-fold axes) in a peripheral shell
  - designation of 12 core subunits as E3BP (one per pentagonal face)
  - positions of lipoyl domains in the gap, and all linker segments (straight/curved bead chains)
  - lipoyl-lysine arms in the "module" file (pseudo-atoms along a line)
Outputs
  PDC_completo.cif   : C-alpha only, full simplified complex
  PDC_modulo.pdb     : one E2 trimer + E1 + E3, backbone + key side chains + cofactors,
                       3 models with the lipoyl domain at the E1, E2 and E3 active sites
  PDC_rangos.json    : atom-serial ranges per component (for JSmol selections)
"""
import json
import gemmi
import numpy as np
from scipy.spatial import cKDTree
from Bio import Align

rng = np.random.default_rng(7)

# ------------------------------------------------------------------ utilities
def kabsch(P, Q):
    """Rotation R and translation t minimising |R P + t - Q|."""
    pc, qc = P.mean(0), Q.mean(0)
    H = (P - pc).T @ (Q - qc)
    U, S, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    D = np.diag([1, 1, d])
    R = Vt.T @ D @ U.T
    return R, qc - R @ pc

def rot_a_to_b(a, b):
    a = a / np.linalg.norm(a); b = b / np.linalg.norm(b)
    v = np.cross(a, b); c = a @ b
    if np.linalg.norm(v) < 1e-8:
        if c > 0: return np.eye(3)
        p = np.array([1, 0, 0]) if abs(a[0]) < .9 else np.array([0, 1, 0])
        v = np.cross(a, p); v /= np.linalg.norm(v)
        return axis_angle(v, np.pi)
    vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + vx + vx @ vx * (1 / (1 + c))

def axis_angle(u, th):
    u = u / np.linalg.norm(u)
    K = np.array([[0, -u[2], u[1]], [u[2], 0, -u[0]], [-u[1], u[0], 0]])
    return np.eye(3) + np.sin(th) * K + (1 - np.cos(th)) * K @ K

aligner = Align.PairwiseAligner()
aligner.mode = "global"; aligner.open_gap_score = -10; aligner.extend_gap_score = -0.5
aligner.substitution_matrix = Align.substitution_matrices.load("BLOSUM62")

def residues_with_ca(ch):
    return [r for r in ch if r.find_atom("CA", "*") and gemmi.find_tabulated_residue(r.name)
            and gemmi.find_tabulated_residue(r.name).is_amino_acid()]

def matched_ca(ch1, ch2):
    r1, r2 = residues_with_ca(ch1), residues_with_ca(ch2)
    s1 = gemmi.one_letter_code([r.name for r in r1]).replace("X", "M")
    s2 = gemmi.one_letter_code([r.name for r in r2]).replace("X", "M")
    aln = aligner.align(s1, s2)[0]
    P, Q = [], []
    for (a0, a1), (b0, b1) in zip(*aln.aligned):
        for i, j in zip(range(a0, a1), range(b0, b1)):
            P.append(r1[i]["CA"][0].pos.tolist()); Q.append(r2[j]["CA"][0].pos.tolist())
    return np.array(P), np.array(Q)

# Generic "atom record" list: dicts with keys name, resn, resi, chain, elem, xyz, het
def chain_atoms(ch, chain_id, keep, resi_offset=0, het=False):
    out = []
    for r in ch:
        for a in r:
            if keep(r, a):
                out.append(dict(name=a.name, resn=r.name, resi=r.seqid.num + resi_offset,
                                chain=chain_id, elem=a.element.name, xyz=np.array(a.pos.tolist()),
                                het=het or r.het_flag == "H"))
    return out

def xf(atoms, R, t):
    return [dict(a, xyz=R @ a["xyz"] + t) for a in atoms]

def coords(atoms):
    return np.array([a["xyz"] for a in atoms])

CA_ONLY = lambda r, a: a.name == "CA" and r.het_flag != "H"
BACKBONE = lambda r, a: a.name in ("N", "CA", "C", "O") and r.het_flag != "H"

# ------------------------------------------------------------------ E2 core (6CT0)
st = gemmi.read_structure("6CT0.cif.gz")
e2 = st[0][0]
ops = []
for o in st.assemblies[0].generators[0].operators:
    ops.append((np.array(o.transform.mat.tolist()), np.array(o.transform.vec.tolist())))
NCH = len(ops)
e2_all = chain_atoms(e2, "X", lambda r, a: r.het_flag != "H")
core_full = [xf(e2_all, R, t) for R, t in ops]
cent = np.array([coords(c).mean(0) for c in core_full])
r_core = max(np.linalg.norm(coords(c), axis=1).max() for c in core_full)
print("core max radius %.1f A" % r_core)

# operator algebra (find j with op_g * op_i == op_j)
def compose_index(Rg, i):
    R = Rg @ ops[i][0]
    for j, (Rj, tj) in enumerate(ops):
        if np.allclose(R, Rj, atol=1e-3): return j
    raise ValueError

# symmetry axes from rotation matrices
def axis_of(R):
    w, v = np.linalg.eig(R); k = np.argmin(abs(w - 1)); ax = np.real(v[:, k])
    ang = np.degrees(np.arccos(np.clip((np.trace(R) - 1) / 2, -1, 1)))
    return ax / np.linalg.norm(ax), ang

def unique_dirs(ang_target):
    dirs = []
    for R, t in ops:
        ax, ang = axis_of(R)
        if abs(ang - ang_target) < 1:
            for s in (1, -1):
                d = s * ax
                if not any(np.allclose(d, e, atol=1e-3) for e in dirs): dirs.append(d)
    return np.array(dirs)
five = unique_dirs(72.0); three = unique_dirs(120.0)
print("5-fold vertices", len(five), "3-fold vertices", len(three))

def nearest(dirs, p):
    return int(np.argmax(dirs @ (p / np.linalg.norm(p))))
tri_of = np.array([nearest(three, c) for c in cent])
pen_of = np.array([nearest(five, c) for c in cent])
assert all((tri_of == k).sum() == 3 for k in range(20)) and all((pen_of == k).sum() == 5 for k in range(12))

# N-terminal CA of each core chain (start of the catalytic domain; linkers attach here)
first_res = residues_with_ca(e2)[0]
nterm_local = np.array(first_res["CA"][0].pos.tolist())
nterm = np.array([R @ nterm_local + t for R, t in ops])
print("catalytic domain starts at residue", first_res.seqid.num)

# ------------------------------------------------------------------ E1 + PSBD unit
e1st = gemmi.read_structure("1NI4.cif.gz"); e1m = e1st[0]
bst = gemmi.read_structure("1W85.cif.gz"); bm = bst[0]
# 1W85: tetramer A(a) B(b) C(a) D(b); PSBD chain I contacts B and D
best = None
for mapping in ({"A": "A", "B": "B", "C": "C", "D": "D"}, {"A": "C", "B": "D", "C": "A", "D": "B"}):
    P, Q = [], []
    for h, b in mapping.items():
        p, q = matched_ca(e1m[h], bm[b]); P.append(p); Q.append(q)
    P, Q = np.vstack(P), np.vstack(Q)
    mask = np.ones(len(P), bool)
    for it in range(8):  # iterative fit on the conserved core
        R, t = kabsch(Q[mask], P[mask])  # bacterial -> human frame
        dev = np.linalg.norm(Q @ R.T + t - P, axis=1)
        mask = dev < max(2.0, np.percentile(dev, 70))
    rmsd = np.sqrt((dev[mask] ** 2).mean())
    if best is None or rmsd < best[0]: best = (rmsd, R, t, int(mask.sum()), len(P))
print("E1 human/bacterial superposition: RMSD %.2f A over %d of %d CA" % (best[0], best[3], best[4]))
Rb, tb = best[1], best[2]
psbd_b = chain_atoms(bm["I"], "P", lambda r, a: r.het_flag != "H")
psbd_b = xf(psbd_b, Rb, tb)  # into the 1NI4 frame

E1_CHAINS = {"A": "alfa", "B": "beta", "C": "alfa", "D": "beta"}
e1_full = {c: chain_atoms(e1m[c], c, lambda r, a: r.het_flag != "H" or r.name in ("TPP", "MG"))
           for c in E1_CHAINS}
e1_all_xyz = np.vstack([coords(v) for v in e1_full.values()])
# ThDP C2 (catalytic carbon) of both sites
tpp_c2 = [a["xyz"] for v in e1_full.values() for a in v if a["resn"] == "TPP" and a["name"] == "C2"]
# PSBD N- and C-terminal CA
psbd_ca = [a for a in psbd_b if a["name"] == "CA"]
e1_unit_axis = e1_all_xyz.mean(0) - coords(psbd_ca).mean(0)  # points from PSBD to E1 body

# ------------------------------------------------------------------ E3 + E3BD unit
e3st = gemmi.read_structure("1ZY8.cif.gz"); e3m = e3st[0]
e3_full = {c: chain_atoms(e3m[c], c, lambda r, a: r.het_flag != "H" or r.name == "FAD") for c in ("A", "B")}
e3bd = chain_atoms(e3m["K"], "K", lambda r, a: r.het_flag != "H")
# FAD is stored as separate residues in the same chains; make sure it was collected
fad_n5 = [a["xyz"] for v in e3_full.values() for a in v if a["resn"] == "FAD" and a["name"] == "N5"]
cys = {c: {n: [a["xyz"] for a in e3_full[c] if a["resi"] == n and a["name"] == "SG"][0] for n in (45, 50)} for c in ("A", "B")}
e3_all_xyz = np.vstack([coords(v) for v in e3_full.values()])
e3bd_ca = [a for a in e3bd if a["name"] == "CA"]
e3_unit_axis = e3_all_xyz.mean(0) - coords(e3bd_ca).mean(0)

# ------------------------------------------------------------------ lipoyl domain (1FYC)
ld = gemmi.read_structure("1FYC.cif.gz")[0][0]
seq = gemmi.one_letter_code([r.name for r in ld])
k_idx = seq.index("ETDKA") + 3
offset = 259 - ld[k_idx].seqid.num  # renumber to UniProt P10515 (lipoyl-Lys259)
ld_all = chain_atoms(ld, "L", lambda r, a: a.element.name != "H", resi_offset=offset)
ld_all = [a for a in ld_all if 214 <= a["resi"] <= 297]
ld_ca = [a for a in ld_all if a["name"] == "CA"]
LYS = 259
ldX = coords(ld_all); ld_c = ldX.mean(0)
k_ca = [a["xyz"] for a in ld_all if a["resi"] == LYS and a["name"] == "CA"][0]
ld_cterm_ca = ld_ca[-1]["xyz"]; ld_nterm_ca = ld_ca[0]["xyz"]
print("lipoyl domain residues %d-%d, lysine %s%d" % (ld_ca[0]["resi"], ld_ca[-1]["resi"],
      [a["resn"] for a in ld_all if a["resi"] == LYS][0], LYS))

# ------------------------------------------------------------------ assignments
# E3BP designation: one chain per pentagon, balanced among trimers
e3bp_of_pen = {}
load = np.zeros(20, int)
for p in range(12):
    cand = [i for i in range(NCH) if pen_of[i] == p]
    cand.sort(key=lambda i: (load[tri_of[i]], i))
    e3bp_of_pen[p] = cand[0]; load[tri_of[cand[0]]] += 1
E3BP = set(e3bp_of_pen.values())
# E1-binding chain: one per trimer, not E3BP; the one whose N-terminus is nearest the 3-fold axis
e1chain_of_tri = {}
for k in range(20):
    cand = [i for i in range(NCH) if tri_of[i] == k and i not in E3BP]
    cand.sort(key=lambda i: -(nterm[i] @ three[k]) / np.linalg.norm(nterm[i]))
    e1chain_of_tri[k] = cand[0]

# ------------------------------------------------------------------ peripheral placement
R_PSBD = r_core + 52.0   # radius of the PSBD centroid (illustrative)
R_E3BD = r_core + 48.0

def place_unit(atoms_xyz_list, axis_local, anchor_local, direction, radius, spin, tangent_ref):
    """Rotate so axis_local -> direction, spin about it, put anchor at given radius."""
    R1 = rot_a_to_b(axis_local, direction)
    R = axis_angle(direction, spin) @ R1
    t = direction * radius - R @ anchor_local
    return R, t

def best_spin(axis_local, anchor_local, unit_xyz, direction, radius, others_tree, ntry=36):
    best = None
    for s in np.linspace(0, 2 * np.pi, ntry, endpoint=False):
        R, t = place_unit(None, axis_local, anchor_local, direction, radius, s, None)
        X = unit_xyz @ R.T + t
        d, _ = others_tree.query(X)
        score = d.min()
        if best is None or score > best[0]: best = (score, R, t, s)
    return best

core_ca_xyz = np.vstack([coords([a for a in c if a["name"] == "CA"]) for c in core_full])

# E3 first (12), spin chosen so E3BD C-terminus faces its E3BP chain
e3_ca_unit = np.vstack([coords([a for a in v if a["name"] == "CA"]) for v in e3_full.values()] + [coords(e3bd_ca)])
e3_place = {}
e3bd_c_local = e3bd_ca[-1]["xyz"]
for p in range(12):
    d = five[p]; best = None
    for s in np.linspace(0, 2 * np.pi, 72, endpoint=False):
        R, t = place_unit(None, e3_unit_axis, coords(e3bd_ca).mean(0), d, R_E3BD, s, None)
        dist = np.linalg.norm(R @ e3bd_c_local + t - nterm[e3bp_of_pen[p]])
        if best is None or dist < best[0]: best = (dist, R, t)
    e3_place[p] = best[1:]

# E1 (20): spin chosen to maximise clearance from E3s and core, PSBD C-term near its chain
e1_ca_unit = np.vstack([coords([a for a in v if a["name"] == "CA"]) for v in e1_full.values()] + [coords(psbd_ca)])
placed = [core_ca_xyz] + [e3_ca_unit @ R.T + t for R, t in e3_place.values()]
e1_place = {}
psbd_c_local = psbd_ca[-1]["xyz"]
for k in range(20):
    d = three[k]; tree = cKDTree(np.vstack(placed)); best = None
    for s in np.linspace(0, 2 * np.pi, 72, endpoint=False):
        R, t = place_unit(None, e1_unit_axis, coords(psbd_ca).mean(0), d, R_PSBD, s, None)
        X = e1_ca_unit @ R.T + t
        clear = tree.query(X)[0].min()
        link = np.linalg.norm(R @ psbd_c_local + t - nterm[e1chain_of_tri[k]])
        score = min(clear, 12.0) - 0.05 * link
        if best is None or score > best[0]: best = (score, R, t, clear, link)
    e1_place[k] = best[1:3]
    placed.append(e1_ca_unit @ best[1].T + best[2])
print("min clearance E1 %.1f A" % min(cKDTree(np.vstack(placed[:1+12])).query(np.vstack(placed[13:]))[0]))

# ------------------------------------------------------------------ linkers
def bead_path(p0, p1, bulge, step=3.8):
    """Quadratic Bezier from p0 to p1 bowed outward by 'bulge' (vector)."""
    mid = (p0 + p1) / 2 + bulge
    ts = np.linspace(0, 1, 400)
    pts = ((1 - ts)[:, None] ** 2) * p0 + (2 * (1 - ts) * ts)[:, None] * mid + (ts[:, None] ** 2) * p1
    seg = np.r_[0, np.cumsum(np.linalg.norm(np.diff(pts, axis=0), axis=1))]
    n = max(2, int(seg[-1] / step))
    s = np.linspace(0, seg[-1], n + 1)[1:-1]
    return np.array([pts[np.searchsorted(seg, x)] for x in s])

# ------------------------------------------------------------------ lipoyl domains in the gap
def place_lipoyl_gap(i, tree, anchor):
    """Random but clash-free position for the lipoyl domain of chain i."""
    base = nterm[i] / np.linalg.norm(nterm[i])
    for _ in range(4000):
        q = rng.normal(size=4); q /= np.linalg.norm(q)
        w, x, y, z = q
        R = np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
                      [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
                      [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
        tang = rng.normal(size=3); tang -= (tang @ base) * base
        dirn = base + tang / np.linalg.norm(tang) * rng.uniform(0, 0.28)
        dirn /= np.linalg.norm(dirn)
        c = dirn * rng.uniform(r_core + 18, r_core + 34)
        t = c - R @ ld_c
        X = coords(ld_ca) @ R.T + t
        if tree.query(X)[0].min() > 6.0 and np.linalg.norm(R @ ld_cterm_ca + t - anchor) < 60:
            return R, t
    raise RuntimeError("no place for lipoyl domain %d" % i)

# ------------------------------------------------------------------ assemble full CA model
groups = {k: [] for k in ("e2", "e3bp", "psbd", "e1a", "e1b", "e3", "e3bd", "lipoil", "lys", "conector")}
chain_counter = [0]
def new_chain():
    chain_counter[0] += 1
    n = chain_counter[0]
    return "%s%d" % ("ABCDEFGHIJKLMNOPQRSTUVWXYZ"[(n - 1) // 100], (n - 1) % 100 + 1)

core_ca = {}
for i in range(NCH):
    ch = new_chain()
    atoms = [dict(a, chain=ch) for a in core_full[i] if a["name"] == "CA"]
    core_ca[i] = atoms
for i in range(NCH):
    (groups["e3bp"] if i in E3BP else groups["e2"]).append(core_ca[i])

psbd_full_xyz = {}
for k, (R, t) in e1_place.items():
    for c, kind in E1_CHAINS.items():
        ch = new_chain()
        groups["e1a" if kind == "alfa" else "e1b"].append(
            [dict(a, chain=ch, xyz=R @ a["xyz"] + t) for a in e1_full[c] if a["name"] == "CA" and not a["het"]])
    ch = new_chain()
    ps = [dict(a, chain=ch, xyz=R @ a["xyz"] + t) for a in psbd_ca]
    groups["psbd"].append(ps); psbd_full_xyz[k] = ps
for p, (R, t) in e3_place.items():
    for c in ("A", "B"):
        ch = new_chain()
        groups["e3"].append([dict(a, chain=ch, xyz=R @ a["xyz"] + t) for a in e3_full[c] if a["name"] == "CA" and not a["het"]])
    ch = new_chain()
    groups["e3bd"].append([dict(a, chain=ch, xyz=R @ a["xyz"] + t) for a in e3bd_ca])

occupied = [coords(sum((g for k in ("e2", "e3bp", "psbd", "e1a", "e1b", "e3", "e3bd") for g in groups[k]), []))]
psbd_of_chain = {e1chain_of_tri[k]: psbd_full_xyz[k] for k in range(20)}
e3bd_of_chain = {e3bp_of_pen[p]: groups["e3bd"][p] for p in range(12)}
lip_pose = {}
for i in range(NCH):
    tree = cKDTree(np.vstack(occupied))
    if i in psbd_of_chain:
        anchor = psbd_of_chain[i][0]["xyz"]          # PSBD N-terminus
    elif i in e3bd_of_chain:
        anchor = e3bd_of_chain[i][0]["xyz"]          # E3BD N-terminus
    else:
        anchor = nterm[i]
    R, t = place_lipoyl_gap(i, tree, anchor)
    lip_pose[i] = (R, t)
    ch = new_chain()
    lca = [dict(a, chain=ch, xyz=R @ a["xyz"] + t) for a in ld_ca]
    groups["lipoil"].append(lca)
    occupied.append(coords(lca))
    # lysine marker (NZ) kept as a separate group
    groups["lys"].append([dict(a, chain=ch, xyz=R @ a["xyz"] + t, het=False)
                          for a in ld_all if a["resi"] == LYS and a["name"] == "NZ"])

def linker(p0, p1, outward=8.0):
    mid = (p0 + p1) / 2
    bulge = mid / np.linalg.norm(mid) * outward
    pts = bead_path(p0, p1, bulge)
    ch = new_chain()
    return [dict(name="CA", resn="GLY", resi=900 + j, chain=ch, elem="C", xyz=x, het=False) for j, x in enumerate(pts)]

for i in range(NCH):
    R, t = lip_pose[i]
    lip_c = R @ ld_cterm_ca + t
    if i in psbd_of_chain:
        ps = psbd_of_chain[i]
        groups["conector"].append(linker(lip_c, ps[0]["xyz"]))
        groups["conector"].append(linker(ps[-1]["xyz"], nterm[i]))
    elif i in e3bd_of_chain:
        bd = e3bd_of_chain[i]
        groups["conector"].append(linker(lip_c, bd[0]["xyz"]))
        groups["conector"].append(linker(bd[-1]["xyz"], nterm[i]))
    else:
        groups["conector"].append(linker(lip_c, nterm[i]))

# write mmCIF (CA only) with contiguous serial ranges per group
order = ["e2", "e3bp", "psbd", "e1a", "e1b", "e3", "e3bd", "lipoil", "lys", "conector"]
lines = ["data_PDC_completo", "#", "loop_",
         "_atom_site.group_PDB", "_atom_site.id", "_atom_site.type_symbol", "_atom_site.label_atom_id",
         "_atom_site.label_alt_id", "_atom_site.label_comp_id", "_atom_site.label_asym_id",
         "_atom_site.label_entity_id", "_atom_site.label_seq_id", "_atom_site.pdbx_PDB_ins_code",
         "_atom_site.Cartn_x", "_atom_site.Cartn_y", "_atom_site.Cartn_z", "_atom_site.occupancy",
         "_atom_site.B_iso_or_equiv", "_atom_site.auth_seq_id", "_atom_site.auth_comp_id",
         "_atom_site.auth_asym_id", "_atom_site.auth_atom_id", "_atom_site.pdbx_PDB_model_num"]
ranges = {}; serial = 0
for gi, g in enumerate(order):
    start = serial + 1
    for chain_atoms_ in groups[g]:
        for a in chain_atoms_:
            serial += 1
            x, y, z = a["xyz"]
            nm = "NZ" if g == "lys" else a["name"]
            el = "N" if g == "lys" else "C"
            ch = a["chain"] + ("K" if g == "lys" else "")
            lines.append("ATOM %d %s %s . %s %s %d %d ? %.3f %.3f %.3f 1.00 %.2f %d %s %s %s 1" % (
                serial, el, nm, a["resn"], ch, gi + 1, a["resi"], x, y, z, 20.0 + gi, a["resi"], a["resn"], ch, nm))
    ranges[g] = [start, serial]
lines.append("#")
open("PDC_completo.cif", "w").write("\n".join(lines) + "\n")
print("PDC_completo.cif atoms", serial, ranges)
allxyz = np.array([a["xyz"] for g in order for c in groups[g] for a in c])
print("outer radius %.1f A (diameter %.1f nm)" % (np.linalg.norm(allxyz, axis=1).max(), 2 * np.linalg.norm(allxyz, axis=1).max() / 10))

# ================================================================== module file
# trimer T0: choose a trimer containing an E3BP chain; E3 at that pentagon, E1 on the trimer
T0 = next(k for k in range(20) if any(i in E3BP and tri_of[i] == k for i in range(NCH)))
tri_chains = [i for i in range(NCH) if tri_of[i] == T0]
c_e1 = e1chain_of_tri[T0]
c_bp = next(i for i in tri_chains if i in E3BP)
p0 = pen_of[c_bp]
R1, t1 = e1_place[T0]; R3, t3 = e3_place[p0]
print("module: trimer", T0, "chains", tri_chains, "E1 chain", c_e1, "E3BP chain", c_bp)

KEEP_SC_E2 = {620, 624}
mod_atoms = []
cid = iter("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
chain_names = {}
for i in tri_chains:
    ch = next(cid); chain_names[i] = ch
    for a in core_full[i]:
        if a["name"] in ("N", "CA", "C", "O") or a["resi"] in KEEP_SC_E2:
            mod_atoms.append(dict(a, chain=ch))
e1ch = {}
for c in E1_CHAINS:
    ch = next(cid); e1ch[c] = ch
    for a in e1_full[c]:
        keep = a["name"] in ("N", "CA", "C", "O") or a["het"] or (E1_CHAINS[c] == "alfa" and a["resi"] in (203, 264, 271))
        if keep: mod_atoms.append(dict(a, chain=ch, xyz=R1 @ a["xyz"] + t1))
chP = next(cid)
for a in psbd_b:
    if a["name"] in ("N", "CA", "C", "O"): mod_atoms.append(dict(a, chain=chP, xyz=R1 @ a["xyz"] + t1))
e3ch = {}
for c in ("A", "B"):
    ch = next(cid); e3ch[c] = ch
    for a in e3_full[c]:
        if a["name"] in ("N", "CA", "C", "O") or a["het"] or a["resi"] in (45, 50, 452):
            mod_atoms.append(dict(a, chain=ch, xyz=R3 @ a["xyz"] + t3))
chB = next(cid)
for a in e3bd:
    if a["name"] in ("N", "CA", "C", "O"): mod_atoms.append(dict(a, chain=chB, xyz=R3 @ a["xyz"] + t3))
static_xyz = coords(mod_atoms)
static_tree = cKDTree(static_xyz)

# active-site targets in the module frame
t_e1 = [R1 @ x + t1 for x in tpp_c2]
his = [a["xyz"] for i in tri_chains for a in core_full[i] if a["resi"] == 620 and a["name"] == "NE2"]
t_e3 = [R3 @ ((cys[c][45] + cys[c][50]) / 2) + t3 for c in ("A", "B")]

def open_direction(T, prefer):
    """Direction from target T with fewest atoms around a 22-A ray; favours 'prefer'."""
    best = None
    v = rng.normal(size=(3000, 3)); v /= np.linalg.norm(v, axis=1)[:, None]
    for d in v:
        pts = T + np.outer(np.linspace(4, 24, 11), d)
        n = sum(len(x) for x in static_tree.query_ball_point(pts, 4.0))
        score = n - 3.0 * (d @ prefer)
        if best is None or score < best[0]: best = (score, d, n)
    return best[1], best[2]

def open_directions(T, prefer, ntop=40):
    v = rng.normal(size=(3000, 3)); v /= np.linalg.norm(v, axis=1)[:, None]
    out = []
    for d in v:
        pts = T + np.outer(np.linspace(4, 24, 11), d)
        n = sum(len(x) for x in static_tree.query_ball_point(pts, 4.0))
        out.append((n - 3.0 * (d @ prefer), n, d))
    out.sort(key=lambda x: x[0])
    return out[:ntop]

def lipoyl_at(T, prefer):
    v_local = ld_c - k_ca
    best = None
    for _, n, d in open_directions(T, prefer):
        for L in (14.0, 15.5, 17.0):
            kpos = T + d * L
            for s in np.linspace(0, 2 * np.pi, 36, endpoint=False):
                for tilt in (0.0, 0.35):
                    w = np.cross(d, [0.2, 0.7, 0.1]); w /= np.linalg.norm(w)
                    dd = axis_angle(axis_angle(d, s) @ w, tilt) @ d
                    R = axis_angle(d, s) @ rot_a_to_b(v_local, dd)
                    t = kpos - R @ k_ca
                    X = ldX @ R.T + t
                    clear = static_tree.query(X)[0].min()
                    score = min(clear, 4.0) - 0.15 * (L - 14.0) - 0.05 * n
                    if best is None or score > best[0]: best = (score, R, t, d, n, clear)
    return best[1], best[2], best[3], best[4], best[5]

def pick_site(targets, prefer):
    res = [(lipoyl_at(T, prefer), T) for T in targets]
    res.sort(key=lambda x: (-min(x[0][4], 3.5), x[0][3]))
    return res[0]

center_tri = np.vstack([coords(core_full[i]) for i in tri_chains]).mean(0)
out_dir = center_tri / np.linalg.norm(center_tri)
poses = []
for name, targets, prefer in (("E1", t_e1, -out_dir), ("E2", his, out_dir), ("E3", t_e3, -out_dir)):
    (R, t, d, n, clear), T = pick_site(targets, prefer)
    poses.append((name, R, t, T))
    print("pose %s: ray atoms %d, clearance %.1f A" % (name, n, clear))

def arm_atoms(kca, T, ch, resi):
    """Lys side chain + lipoyl group as pseudo-atoms on a zigzag from Lys CA to the site."""
    d = T - kca; L = np.linalg.norm(d); d /= L
    perp = np.cross(d, [0.3, 0.5, 0.8]); perp /= np.linalg.norm(perp)
    names_lys = ["CB", "CG", "CD", "CE", "NZ"]
    names_lip = ["C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "S6", "S8"]
    n = len(names_lys) + len(names_lip)
    out = []
    for j in range(n):
        f = (j + 1) / (n + 0.6)
        p = kca + d * L * f + perp * (0.45 if j % 2 else -0.45)
        if j < 5:
            out.append(dict(name=names_lys[j], resn="LYS", resi=resi, chain=ch, elem="N" if names_lys[j] == "NZ" else "C", xyz=p, het=False))
        else:
            nm = names_lip[j - 5]
            out.append(dict(name=nm, resn="LPA", resi=resi + 1000, chain=ch, elem="S" if nm.startswith("S") else "C", xyz=p, het=True))
    return out

chL = next(cid); chX = next(cid)
models = []
psbd_mod = [a for a in mod_atoms if a["chain"] == chP and a["name"] == "CA"]
for name, R, t, T in poses:
    lip = []
    for a in ld_all:
        if a["name"] in ("N", "CA", "C", "O") or (a["resi"] == LYS and a["name"] == "CA"):
            lip.append(dict(a, chain=chL, xyz=R @ a["xyz"] + t))
    kca = R @ k_ca + t
    lip = [a for a in lip if not (a["resi"] == LYS and a["name"] not in ("N", "CA", "C", "O"))]
    arm = arm_atoms(kca, T, chL, LYS)
    # linkers: lipoyl C-term -> PSBD N-term ; PSBD C-term -> catalytic N-terminus of chain c_e1
    p_lc = R @ ld_cterm_ca + t
    seg1 = bead_path(p_lc, psbd_mod[0]["xyz"], ((p_lc + psbd_mod[0]["xyz"]) / 2 - center_tri) * 0.0)
    seg2 = bead_path(psbd_mod[-1]["xyz"], nterm[c_e1], np.zeros(3))
    lk = [dict(name="CA", resn="GLY", resi=900 + j, chain=chX, elem="C", xyz=x, het=False)
          for j, x in enumerate(list(seg1) + list(seg2))]
    models.append(mod_atoms + lip + arm + lk)

# E3BD linker (static): E3BD C-term -> catalytic N-terminus of the E3BP chain
bd_mod = [a for a in mod_atoms if a["chain"] == chB and a["name"] == "CA"]
seg3 = bead_path(bd_mod[-1]["xyz"], nterm[c_bp], np.zeros(3))
chY = next(cid)
lk3 = [dict(name="CA", resn="GLY", resi=950 + j, chain=chY, elem="C", xyz=x, het=False) for j, x in enumerate(seg3)]
models = [m + lk3 for m in models]

# centre the module at the origin for a stable view
ctr = static_xyz.mean(0)
# orient: radial (outward) direction -> +y, E1->E3 vector roughly along +x
Rv = rot_a_to_b(out_dir, np.array([0., 1., 0.]))
e1c = Rv @ (np.vstack([coords(v) for v in e1_full.values()]) @ R1.T + t1).mean(0)
e3c = Rv @ (e3_all_xyz @ R3.T + t3).mean(0)
h = e3c - e1c; h[1] = 0; h /= np.linalg.norm(h)
Rv = axis_angle(np.array([0., 1., 0.]), -np.arctan2(-h[2], h[0])) @ Rv
with open("PDC_modulo.pdb", "w") as f:
    f.write("REMARK   1 MODELO DOCENTE SIMPLIFICADO DEL COMPLEJO PIRUVATO DESHIDROGENASA\n")
    f.write("REMARK   1 MODELO 1: DOMINIO LIPOILO EN E1; 2: EN E2; 3: EN E3\n")
    for mi, m in enumerate(models, 1):
        f.write("MODEL     %4d\n" % mi)
        for s, a in enumerate(m, 1):
            x, y, z = Rv @ (a["xyz"] - ctr)
            rec = "HETATM" if a["het"] else "ATOM  "
            nm = a["name"]; nmf = (" " + nm) if len(nm) < 4 and len(a["elem"]) == 1 else nm
            f.write("%s%5d %-4s %3s %1s%4d    %8.3f%8.3f%8.3f  1.00 20.00          %2s\n" % (
                rec, s % 100000, nmf[:4], a["resn"][:3], a["chain"], a["resi"] % 10000, x, y, z, a["elem"][:2]))
        f.write("ENDMDL\n")
    f.write("END\n")
info = dict(ranges=ranges, modulo=dict(e2=[chain_names[i] for i in tri_chains if i not in (c_e1, c_bp)],
            e2_e1=chain_names[c_e1], e3bp=chain_names[c_bp], e1=e1ch, psbd=chP, e3=e3ch, e3bd=chB,
            lipoil=chL, conectores=[chX, chY]))
json.dump(info, open("PDC_rangos.json", "w"), indent=1)
print(json.dumps(info))
