# ma-iegv0 with superposed tRNAs: JSmol files for the Atlas

Human multi-tRNA synthetase complex model ModelArchive ma-iegv0 (https://doi.org/10.5452/ma-iegv0), with 13 tRNAs placed by rigid superposition of experimental synthetase–tRNA complexes, one per tRNA-binding site of each synthetase. The tRNA positions are approximate and are meant for teaching, not for analysis.

## Files

| File | Atoms | Size | Content |
|---|---|---|---|
| `ma-iegv0_tRNA_atlas.cif.gz` | 103,977 | 1.14 MB | All heavy atoms. Use this file when a page shows side chains, active sites or clashes. |
| `ma-iegv0_tRNA_atlas_light.cif.gz` | 62,594 | 0.69 MB | Protein backbone only (N, CA, C, O); tRNAs keep all atoms. Enough for cartoon, trace and backbone views. |
| `make_atlas_cif.py` | | | Builds both files from `ma-iegv0_with_tRNAs.cif` (`python3 make_atlas_cif.py [--light]`). |

Changes from the full overlay file:

- The tRNA placed on the AIMP1 C-terminal domain (chain `tXI`) is left out, because AIMP1 is not a synthetase.
- Only the 10 `_atom_site` columns JSmol reads are kept.
- Coordinates are rounded to 0.01 Å.
- 116 duplicated partial-occupancy atoms are removed, keeping the one with the higher occupancy.
- Helices and strands are stored in `_struct_conf` and `_struct_sheet_range`, computed with DSSP in Jmol 14.31, so JSmol skips the secondary-structure calculation.
- Modified nucleotides (PSU, H2U, 5MC and others) are written as ATOM records, so they stay in the tRNA cartoon.

## Chains

| Chain | Protein | | Chain | tRNA (host) |
|---|---|---|---|---|
| A | MetRS | | tKH, tKM | tRNA-Lys (LysRS H, M) |
| B | AIMP3 | | tDE, tDL | tRNA-Asp (AspRS E, L) |
| C, N | GluProRS | | tEC, tEN | tRNA-Glu (GluProRS C, N) |
| D | AIMP2 | | tPC, tPN | tRNA-Pro (GluProRS C, N) |
| E, L | AspRS | | tQF | tRNA-Gln (GlnRS F) |
| F | GlnRS | | tRG | tRNA-Arg (ArgRS G) |
| G | ArgRS | | tIJ | tRNA-Ile (IleRS J) |
| H, M | LysRS | | tLK | tRNA-Leu (LeuRS K) |
| I | AIMP1 | | tMA | tRNA-Met (MetRS A) |
| J | IleRS | | | |
| K | LeuRS | | | |

Chain names are case-sensitive: `select :tKH` works and `select :tkh` selects nothing. `select nucleic` selects all tRNAs; `select protein` selects all proteins.

## Use in an Atlas page

The file needs JSmol's CIF reader, so `j2sPath` must point to the complete `jsmol/j2s` tree, as in the heme page. Example in the style of the existing pages:

```html
<script>
  jmolInitialize("./jsmol/js");
  jmolApplet(420, "load ./pdb/ma-iegv0_tRNA_atlas_light.cif.gz; "
    + "select *; spacefill off; wireframe off; cartoon on; "
    + "select protein; color cartoon chain; "
    + "select nucleic; color cartoon [220,40,40]; cartoon 0.8; select *;");
</script>
<input type="button" value="LysRS + tRNA-Lys"
  onclick="jmolScript('display :H or :tKH; zoomto 1 (:H or :tKH) 0;')">
<input type="button" value="Complejo completo"
  onclick="jmolScript('display all; zoomto 1 (all) 0;')">
```

Loading takes about 8–10 s in a headless test browser; most of that time is parsing and building the scene for this many atoms.
